package Utils;

public enum Treatments {
	
	ANTIVIRAL,BREATHING_SUPPORT, STEROIDS,BLOOD_PLASMA_TRANSFUSIONS
}
