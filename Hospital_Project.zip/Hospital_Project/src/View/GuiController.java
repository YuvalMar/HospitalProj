package View;


import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

import javax.swing.JOptionPane;

import com.sun.javafx.scene.control.behavior.TextAreaBehavior;

import Exceptions.EmptyFieldException;
import Exceptions.NameException;
import Exceptions.PasswordTooShortException;
import Exceptions.UserLoginException;
import Model.ChronicDisease;
import Model.Department;
import Model.Disease;
import Model.Doctor;
import Model.Hospital;
import Model.HospitalUser;
import Model.Nurse;
import Model.Patient;
import Model.PatientReport;
import Model.SubDepartment;
import Utils.ReleaseNote;
import Utils.Specialization;
import Utils.Symptoms;
import Utils.Treatments;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuBar;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.SkinBase;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.skin.TextAreaSkin;
import javafx.scene.control.skin.TextFieldSkin;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.StageStyle;

public class GuiController {
	
		
	 @FXML
	 private VBox mainScreen;
	 @FXML
	 private StackPane stack;
	 @FXML
	 private AnchorPane changing;
	 
	 @FXML
	 private ProgressBar prog;
	 
	 
	 
	 @FXML
	 private Button saveButton;
	 @FXML
	 private Button printButton;
	 @FXML
	 private Button login;
	 @FXML
	 private RadioButton docButton;
	 @FXML
	 private RadioButton nurButton;
	 @FXML
	 private RadioButton admin;
	 @FXML
	 private ToggleGroup group;
	 
	 
	 @FXML
	 private TextField firstName;
	 @FXML
	 private TextField lastName;
	 @FXML
	 private TextField ID;
	 @FXML
	 private TextField status;

	 
	 @FXML
	 private PasswordField password;
	 
	 //***Admin***//
	 
	 @FXML
	 private ChoiceBox<Department> depts = new ChoiceBox<Department>();
	 @FXML
	 private ChoiceBox<SubDepartment> subDep = new ChoiceBox<SubDepartment>();
	 @FXML
	 private ChoiceBox<SubDepartment> subDepToMoveTo = new ChoiceBox<SubDepartment>();
	 @FXML
	 private ChoiceBox<SubDepartment> toMoveTo = new ChoiceBox<SubDepartment>();
	 @FXML
	 private ChoiceBox<Disease> diseases = new ChoiceBox<Disease>();
	 @FXML
	 private ChoiceBox<Patient> patients = new ChoiceBox<Patient>();
	 @FXML
	 private ChoiceBox<Doctor> doctors = new ChoiceBox<Doctor>();
	 @FXML
	 private ChoiceBox<Nurse> nurses = new ChoiceBox<Nurse>();
	 @FXML
	 private ChoiceBox<PatientReport> patientReports = new ChoiceBox<PatientReport>();
	 @FXML
	 private ChoiceBox<Specialization> specializations = new ChoiceBox<Specialization>();
	 @FXML
	 private ChoiceBox<ReleaseNote> rNotes = new ChoiceBox<ReleaseNote>();
	 @FXML
	 private ChoiceBox<Symptoms> symptoms = new ChoiceBox<Symptoms>();
	 @FXML
	 private ChoiceBox<Treatments> treatments = new ChoiceBox<Treatments>();
	 @FXML
	 private ChoiceBox<Character> fromChar = new ChoiceBox<Character>();
	 @FXML
	 private ChoiceBox<Character> toChar = new ChoiceBox<Character>();
	 
	 @FXML
	 private ListView<Symptoms> symptomsList = new ListView<Symptoms>();
	 
	 //**Doctor or Nurse**//
	 @FXML
	 private ChoiceBox<Patient> usersPatients = new ChoiceBox<Patient>();
	 @FXML
	 private ChoiceBox<Patient> usersHotelPatients = new ChoiceBox<Patient>();
	 @FXML
	 private ChoiceBox<Nurse> usersNurses = new ChoiceBox<Nurse>();
	 
	 @FXML
	 private Label moveTo;
	 
	 
	 private final String passwordFail = "Password is incorrect.";
	 private final String noUser = "User not found";
	 private final String nullPointer = "The system cannot complete your request. Some information might be missing.";
	 
	 
	 ObservableList<SubDepartment> allSubDepts = FXCollections.observableArrayList
			 (Hospital.getInstance().getSubDepartmentById().values());
	 ObservableList<Department> allDepts = FXCollections.observableArrayList
			 (Hospital.getInstance().getDepartmentsById().values());
	 ObservableList<Disease> allDiseases = FXCollections.observableArrayList
			 (Hospital.getInstance().getDiseasesById().values());
	 ObservableList<Specialization> allSpecs = FXCollections.observableArrayList
			 (Specialization.values());
	 ObservableList<ReleaseNote> allNotes = FXCollections.observableArrayList
			 (ReleaseNote.values());
	 ObservableList<Symptoms> allSymptoms = FXCollections.observableArrayList
			 (Symptoms.values());
	 ObservableList<Treatments> allTreatments = FXCollections.observableArrayList
			 (Treatments.values());
	 ObservableList<Patient> allPatients = FXCollections.observableArrayList
			 (Hospital.getInstance().getPatientsById().values());
	 ObservableList<Doctor> allDoctors = FXCollections.observableArrayList
			 (Hospital.getInstance().getDoctorsById().values());
	 ObservableList<Nurse> allNurses = FXCollections.observableArrayList
			 (Hospital.getInstance().getNursesById().values());
	 ObservableList<PatientReport> allPatientReports = FXCollections.observableArrayList
			 (Hospital.getInstance().getReportsById().values());
	 
	 ObservableList<Patient> usrPatients;
	 ObservableList<Nurse> usrNurses;
	 
	 
	 

	 ArrayList<Character> charList = new ArrayList<Character>();
	 char[] alphabet = "abcdefghijklmnopqrstuvwxyz".toCharArray();
	 ObservableList<Character> charactersList;
	 
	 
	 @FXML
	 void initialize() {
		 subDep.getItems().addAll(allSubDepts);
		 subDepToMoveTo.getItems().addAll(allSubDepts);
		 depts.getItems().addAll(allDepts);
		 symptoms.getItems().addAll(allSymptoms);
		 diseases.getItems().addAll(allDiseases);
		 specializations.getItems().addAll(allSpecs);
		 rNotes.getItems().addAll(allNotes);
		 patients.getItems().addAll(allPatients);
		 doctors.getItems().addAll(allDoctors);
		 nurses.getItems().addAll(allNurses);
		 treatments.getItems().addAll(allTreatments);
		 symptomsList.getItems().addAll(allSymptoms);
		 patientReports.getItems().addAll(allPatientReports);
		 symptomsList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
		 for( char c : alphabet)
			 charList.add(c);
		 fromChar.getItems().addAll(FXCollections.observableArrayList(charList));
		 toChar.getItems().addAll(FXCollections.observableArrayList(charList));
		 if( MainGui.currentDoctor != null )
			 docsListsInitialize();
		 if( MainGui.currentNurse != null )
			 nurseListInitialize();
		 
	 }
	 
	 	 @FXML
	 	 void addDoctor(ActionEvent event) {
	 		FXMLLoader loader = new FXMLLoader(getClass().getResource("addDoctor.fxml"));
			MainGui.whatToDo = "addDoctor";
			loadScreen(loader);
	    }
	 	     
	    @FXML
	    void addPatient(ActionEvent event)  {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("addPatient.fxml"));
			MainGui.whatToDo = "addPatient";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void addNurse(ActionEvent event) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("addNurse.fxml"));
			MainGui.whatToDo = "addNurse";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void addDisease(ActionEvent event) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("addDisease.fxml"));
			MainGui.whatToDo = "addDisease";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void addDepartment(ActionEvent event) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("addDepartment.fxml"));
			MainGui.whatToDo = "addDepartment";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void addSubDepartment(ActionEvent event) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("addSubDept.fxml"));
			MainGui.whatToDo = "addSubDepartment";
			loadScreen(loader);
	    }
	      
	    @FXML
	    void addPatientReport(ActionEvent event) {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("addPatientReport.fxml"));
			MainGui.whatToDo = "addPatientReport";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void removeDepartment(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("removeDepartment.fxml"));
			MainGui.whatToDo = "removeDepartment";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void removeSubDepartment(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("removeSubDept.fxml"));
			MainGui.whatToDo = "removeSubDept";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void removeDisease(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("removeDisease.fxml"));
			MainGui.whatToDo = "removeDisease";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void removeDoctor(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("removeDoctor.fxml"));
			MainGui.whatToDo = "removeDoctor";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void removeNurse(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("removeNurse.fxml"));
			MainGui.whatToDo = "removeNurse";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void removeRecoveredPatient(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("removeRecoveredPatient.fxml"));
			MainGui.whatToDo = "removeRecoveredPatient";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void removeReport(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("removeReport.fxml"));
			MainGui.whatToDo = "removeReport";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void removeToHotel(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("removeToHotel.fxml"));
			MainGui.whatToDo = "removeToHotel";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void printAllDocs(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("printAllDocs.fxml"));
			MainGui.whatToDo = "printAllDocs";
			loadScreen(loader);	
	    }
	    
	    @FXML
	    void printAllNurses(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("printAllNurses.fxml"));
			MainGui.whatToDo = "printAllNurses";
			loadScreen(loader);	
	    }
	    
	    @FXML
	    void printAllPatients(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("printAllPatients.fxml"));
			MainGui.whatToDo = "printAllPatients";
			loadScreen(loader);	
	    }
	    
	    @FXML
	    void allDifficultBreathingPatients(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("allDifficultBreathingPatients.fxml"));
			MainGui.whatToDo = "allDifficultBreathingPatients";
			loadScreen(loader);	
	    }
	    
	    @FXML
	    void allBadConditionPatients(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("allBadConditionPatients.fxml"));
			MainGui.whatToDo = "allBadConditionPatients";
			loadScreen(loader);	
	    }
	    
	    @FXML
	    void doctorsBySpecialization(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("doctorBySpecialiation.fxml"));
			MainGui.whatToDo = "doctorBySpecialiation";
			loadScreen(loader);	
	    }
	    
	    @FXML
	    void diseasesByRange(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("diseasesByRange.fxml"));
			MainGui.whatToDo = "diseasesByRange";
			loadScreen(loader);	
	    }
	    
	    @FXML
	    void treatPatient(ActionEvent event) {
	    	
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("treatPatient.fxml"));
			MainGui.whatToDo = "treatPatient";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void treatDiseases(ActionEvent event) {
	    	
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("treatDiseases.fxml"));
			MainGui.whatToDo = "treatDiseases";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void checkPatient(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("checkPatient.fxml"));
			MainGui.whatToDo = "checkPatient";
			loadScreen(loader);
	    }
	    
	    @FXML
	    void checkDisease(ActionEvent event) {
	    	FXMLLoader loader = new FXMLLoader(getClass().getResource("checkDisease.fxml"));
			MainGui.whatToDo = "checkDisease";
			loadScreen(loader);
	    }
	    
	    
	    @FXML
	    void bestStatusSubDepts(ActionEvent event) {
	    	
	    	try {
	    		Alert alert = new Alert(AlertType.INFORMATION);
	    		alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
	    		String subDepts = "";
	    		TreeSet<SubDepartment> subTree = Hospital.getInstance().getBestStatusSubDepartments();
	    		for(SubDepartment s : subTree)
	    			subDepts += (s + "\n");
	    		alert.setTitle("Best Status Sub Departments");
	    		alert.setHeaderText("Best Status Sub Departments :");
	    		if( subTree.isEmpty() )
	    			alert.setContentText("There are no sub departments to show!");
	    		else if( !subTree.isEmpty() )
	    			alert.setContentText(subDepts);
	    		alert.showAndWait();
	    	}catch(NullPointerException e) {
	    			showAlert(AlertType.ERROR, "Error", "System Error", nullPointer);
	    			return;
	    		}
	    }
	    
	    @FXML
	    void criticalSteroidsNeuPatient(ActionEvent event) {
	    	try {
	    		
	    		String pat = "";
	    		String title = "Critical Steroids Neu Patient";
	    		String header = "Critical Steroids Neu Patient :";
	    		TreeSet<Patient> patTree = Hospital.getInstance().getCriticalSteroidsNeuPatients();
	    		if( patTree.isEmpty() )
	    			pat = "There are no patienst to show!";
	    		else if( !patTree.isEmpty()) {
		    		for(Patient p : patTree)
		    			pat += (p.toStringLong() + "\n");
	    		}
	    		printAll(title ,header , pat);
	    	}catch(NullPointerException e) {
	    			showAlert(AlertType.ERROR, "Error", "System Error", nullPointer);
	    			return;
	    		}
	    }
	    
	    @FXML
	    void findHardestWorkingNurse(ActionEvent event) {
	    	try {
	    		String title = "Hardest Working Nurse";
	    		String header = "Hardest Working Nurse :";
	    		Nurse nur = Hospital.getInstance().findHardestWorkingNurse();
	    		String content = "";
	    		if( nur==null )
	    			content = "There is no nurse to show!";
	    		else if( nur != null )
	    			content = nur.toStringLong() ;
	    		showAlert(AlertType.INFORMATION, title, header, content);
	    	}catch(NullPointerException e) {
    			showAlert(AlertType.ERROR, "Error", "System Error", nullPointer);
    			return;
    		}
	    }
	    
	    //****Saving Method***//
	    
	    @FXML
	    void save(ActionEvent event) {
	    	try {
	    		boolean res = false;
	    		if(MainGui.whatToDo.equals("addDoctor")) {
	    		
	    			if( firstName.getText().isEmpty() || lastName.getText().isEmpty()|| specializations.getValue()==null || 
	    					subDep.getValue()==null) 
	    				throw new EmptyFieldException();
	    			if( !firstName.getText().matches("[a-zA-Z]+") || !lastName.getText().matches("[a-zA-Z]+") ) 
	    				throw new NameException();
	    			Doctor doc = new Doctor( firstName.getText(), lastName.getText(),
	    					specializations.getValue(), subDep.getValue());
	    			doc.setPassword(password.getText());
	    			res = Hospital.getInstance().addDoctor(doc, subDep.getValue());
	    		}
	    		
	    		if(MainGui.whatToDo.equals("addNurse")) {
	    		
	    			if( firstName.getText().isEmpty() || lastName.getText().isEmpty() || treatments.getValue()==null ||  
	    					subDep.getValue()==null)
	    				throw new EmptyFieldException();
	    			
	    			if( !firstName.getText().matches("[a-zA-Z]+") || !lastName.getText().matches("[a-zA-Z]+"))
	    				throw new NameException();
	    			Nurse nurse = new Nurse(firstName.getText(), lastName.getText(), treatments.getValue(), subDep.getValue());
	    			nurse.setPassword(password.getText());
	    			res = Hospital.getInstance().addNurse(nurse, subDep.getValue());
	    		}
	    	
	    		if(MainGui.whatToDo.equals("addPatient")) {
		    	
		    		if(firstName.getText().isEmpty() || lastName.getText().isEmpty() || subDep.getValue()==null
		    				|| diseases.getValue()==null || status.getText().isEmpty() )
		    			throw new EmptyFieldException();
		    		if( !firstName.getText().matches("[a-zA-Z]+") || !lastName.getText().matches("[a-zA-Z]+"))
		    			throw new NameException();
		    		Patient patient = new Patient(firstName.getText(), lastName.getText(), subDep.getValue(), diseases.getValue() );
		    		int stat = Integer.parseInt(status.getText());
		    		String result = patient.setStatus(stat);
		    		res = Hospital.getInstance().addPatient(patient, subDep.getValue());
		    		if( result.equals("Success"))
		    			if( stat > 100 )
		    			showAlert(AlertType.WARNING, "Status Warning", "Status is not in Range!", 
		    					"The status is not between 0 and 100, status has been set to 100");
		    			else if( stat < 0)
		    				showAlert(AlertType.WARNING, "Status Warning", "Status is not in Range!", 
			    					"The status is not between 0 and 100, status has been set to 0");
	    		}
	    	
	    		if(MainGui.whatToDo.equals("addDisease")) {
	    		
	    			if( firstName.getText().isEmpty() )
	    				throw new EmptyFieldException();
	    			Disease dis = new Disease(firstName.getText());
	    			HashSet<Symptoms> symp =new HashSet<Symptoms>();
	    			symp.addAll(symptomsList.getSelectionModel().getSelectedItems());
	    			String result = dis.setSymptoms(symp);
	    			if( !result.equals("Success")) {
	    				showAlert( AlertType.ERROR, "Symptoms Error", "No Symptoms ", "Please choose symptoms!");
	    				return;	
	    			}
	    			res = Hospital.getInstance().addDisease(dis);
	    		}
	    	
	    		if(MainGui.whatToDo.equals("addDepartment")) {
	    		//Using the firstName TextField for the departments area to not create another TextArea just for Department.
	    		
	    			if( firstName.getText().isEmpty()  || specializations.getValue()==null)
	    				throw new EmptyFieldException();
	    			if( !firstName.getText().matches("[a-zA-Z]+"))
	    				throw new NameException();
	    			Department dept = new Department(firstName.getText(),specializations.getValue());
	    			res = Hospital.getInstance().addDepartment(dept);
	    		}
	    	
	    		if(MainGui.whatToDo.equals("addSubDepartment")) {
	    		
	    			if( depts.getValue()==null )
	    				throw new EmptyFieldException(); 
	    			SubDepartment subDep = new SubDepartment(depts.getValue());
	    			res = Hospital.getInstance().getRealDepartment(depts.getValue().getId()).addSubDepartment(subDep);
	    		}
	    	
	    		if( MainGui.whatToDo.equals("addPatientReport")) {
	    		
	    			if(patients.getValue()==null || doctors.getValue()==null)
	    				throw new EmptyFieldException();
	    			Date d = new Date();
	    			Hospital.getInstance().addPatientReport(patients.getValue(), doctors.getValue(),
	    					d, patients.getValue().getDis(), patients.getValue().checkCondition());
	    			res = true;
	    		} 
	    	
	    		if(MainGui.whatToDo.equals("removeDepartment")) {
	    		
	    			if( depts.getValue()==null)
	    				throw new EmptyFieldException();
	    			res = Hospital.getInstance().removeDepartment(depts.getValue());
	    		}
	    	
	    		if(MainGui.whatToDo.equals("removeSubDept")) {
	    		
	    			if(subDep.getValue()==null)
	    				throw new EmptyFieldException();
	    			if(subDep.isDisable() && subDepToMoveTo.getValue()==null)
	    				throw new EmptyFieldException();
	    			
	    			
	    			if( !subDep.isDisable()) {
	    				
		    			if(!subDep.getValue().getPatients().isEmpty() || !subDep.getValue().getDoctors().isEmpty()
		    					|| !subDep.getValue().getNurses().isEmpty() || !subDep.getValue().getReports().isEmpty()) { 
		    				showAlert(AlertType.ERROR, "Error", "Sub Department is not Empty!", "Please select a sub department "
		    						+ "to move databse");
		    			subDepToMoveTo.getItems().remove(subDep.getValue());
		    			moveTo.setVisible(true);
		    			subDepToMoveTo.setVisible(true);
		    			subDep.setDisable(true);
		    			return;
		    			}
	    			}
	    			Hospital.getInstance().getRealDepartment(subDep.getValue().getDepartment().getId())
	    				.removeSubDepartment(subDep.getValue(), subDepToMoveTo.getValue());
	    			res = true;
	    		}
	    	
	    		if(MainGui.whatToDo.equals("removeDisease")) {
	    		
	    			if(diseases.getValue()==null)
	    				throw new EmptyFieldException();
	    			res = Hospital.getInstance().removeDisease(diseases.getValue());
	    		}
	    	
	    		if(MainGui.whatToDo.equals("removeDoctor")) {
	    		
	    			if(doctors.getValue()==null)
	    				throw new EmptyFieldException();
	    			res = Hospital.getInstance().removeDoctor(doctors.getValue());
	    		}
	    	
	    		if(MainGui.whatToDo.equals("removeNurse")) {
	    		
	    			if( nurses.getValue()==null)
	    				throw new EmptyFieldException();
	    			res = Hospital.getInstance().removeNurse(nurses.getValue());
	    		}
	    	
	    		if(MainGui.whatToDo.equals("removeRecoveredPatient")) {
	    		
	    			if( patients.getValue()==null)
	    				throw new EmptyFieldException();
	    			String result = Hospital.getInstance().removeRecoverPatient(patients.getValue());
	    			if( !result.equals("Success")) {
	    				showAlert(AlertType.ERROR, "Error", "Cannot Release Patient", result);
	    				return;
	    			}
	    			if( result.equals("Success"))
	    				res = true;
	    		}
	    	
	    		if(MainGui.whatToDo.equals("removeReport")) {
	    		
	    			if( patientReports.getValue()==null)
	    				throw new EmptyFieldException();
	    			res = Hospital.getInstance().removePatientReport(patientReports.getValue());
	    		}
	    	
	    		if(MainGui.whatToDo.equals("removeToHotel")) {
	    		
	    			if( patients.getValue()==null)
	    				throw new EmptyFieldException();
	    			String result = Hospital.getInstance().removeToHotelPatient(patients.getValue());
	    			if( !result.equals("Success")) {
	    				showAlert(AlertType.ERROR, "Error", "Cannot Move Patient to Hotel" , result);
	    				return;
	    			}
	    			if( result.equals("Success"))
	    				res = true;
	    		}
	    		
	    		if(res) 
	    			showAlert(AlertType.INFORMATION,"Success", "Success!",null);
	    		if(!res)
	    			showAlert(AlertType.ERROR, "Errot", "Error!", "Try again please");
	    		
	    		if( MainGui.currentDoctor != null )
		    		docsMainScreen();
		    	if(MainGui.currentNurse != null)
		    		nursesMainScreen();
		    	else 
		    		mainScreen();
	    			
	    	}catch(EmptyFieldException e) {
	    		if(MainGui.whatToDo.equals("addDoctor")) {
	    			showAlert(AlertType.ERROR, "Error", "Cannot Add Doctor", e.getMessage());
	    			return;
	    		}
	    		if(MainGui.whatToDo.equals("addNurse")) {
	    			showAlert(AlertType.ERROR, "Error", "Cannot Add Nurse", e.getMessage());
	    			return;
	    		}
	    		if(MainGui.whatToDo.equals("addPatient")) {
	    			showAlert(AlertType.ERROR, "Error", "Cannot Add Patient", e.getMessage());
	    			return;
	    		}
    		
    		}
	    	catch(NameException n) {
	    		if(MainGui.whatToDo.equals("addDoctor")) {
	    			showAlert(AlertType.ERROR, "Error", "Cannot Add Doctor", n.getMessage());
	    			return;
	    		}
	    		if(MainGui.whatToDo.equals("addNurse")) {
	    			showAlert(AlertType.ERROR, "Error", "Cannot Add Nurse", n.getMessage());
	    			return;
	    		}
	    		if(MainGui.whatToDo.equals("addPatient")) {
	    			showAlert(AlertType.ERROR, "Error", "Cannot Add Patient", n.getMessage());
	    			return;
	    		}
	    		
    		}
	    	catch(PasswordTooShortException p) {
    			showAlert(AlertType.ERROR, "Error", "Cannot set Password", "Password must be 6 characters or more");
    			return;
    		}
	    	catch(NumberFormatException num) {
	    		showAlert(AlertType.ERROR, "Status Error", "Invalid Status!", "Status has to be numbers only!");
	    		return;
	    	}
	    	catch(NullPointerException e) {
    			showAlert(AlertType.ERROR, "Error", "System Error", nullPointer);
    			return;
    		}	
	    }
	    
	    
	    //***Display Button Methods***//
	    
	    @FXML
	    void display(ActionEvent event) {
	    	try {
	    		
	    		if(MainGui.whatToDo.equals("printAllDocs")) {
	    			if( depts.getValue()==null )
	    				throw new EmptyFieldException();
	    			String title = "Department's Doctors";
	    			String header = "Department " + depts.getValue().getDeptName() + " Doctors";
	    			String toPrint = depts.getValue().printAllDoctors();
	    			printAll(title, header, toPrint);	
	    		}
	    	
	    		if(MainGui.whatToDo.equals("printAllNurses")) {
	    			if( depts.getValue()==null )
	    				throw new EmptyFieldException();
	    			String title = "Department's Nurses";
	    			String header = "Department " + depts.getValue().getDeptName() + " Nurses";
	    			String toPrint = depts.getValue().printAllNurses();
	    			printAll(title, header, toPrint);
	    		}
	    	
	    		if(MainGui.whatToDo.equals("printAllPatients")) {
	    			if( depts.getValue()==null )
	    				throw new EmptyFieldException();
	    			String title = "Department's Patients";
	    			String header = "Department " + depts.getValue().getDeptName() + " Patients";
	    			String toPrint = depts.getValue().printAllPatients();
	    			printAll(title, header, toPrint);
	    		}
	    	
	    		if(MainGui.whatToDo.equals("allDifficultBreathingPatients")) {
	    			if( depts.getValue()==null )
	    				throw new EmptyFieldException();
	    			LinkedList<Patient> pat = Hospital.getInstance().getAllDifficultBreathingPatients(depts.getValue());
	    			String toPrint = "";
	    			if( pat.isEmpty() )
	    				toPrint = "No patients to show";
	    			else if( !pat.isEmpty() ) {
	    				for(Patient p : pat) 
	    					toPrint += (p.toStringLong()+"\n");
	    			}
	    			String title = "Department's Difficult Breathing Patients";
	    			String header = "Department "+ depts.getValue().getDeptName() + " " + "Difficult Breathing Patients :";
	    			printAll(title, header, toPrint);
	    		}
	    	
	    		if(MainGui.whatToDo.equals("allBadConditionPatients")) {
	    			if( doctors.getValue()==null )
	    				throw new EmptyFieldException();
	    			
	    			ArrayList<Patient> pat = Hospital.getInstance().getAllBadConditionPatients(doctors.getValue());
	    			String toPrint = "";
	    			if( pat.isEmpty() )
	    				toPrint = "No patients to show";
	    			else if( !pat.isEmpty() ) {
	    				for(Patient p : pat) 
	    					toPrint += (p.toStringLong()+"\n");
	    			}
	    			String title = "Doctor's Bad Condition Patients";
	    			String header = "Doctor "+ doctors.getValue().getLname() + " " + "Bad Condition Patients :";
	    			printAll(title, header, toPrint);
	    		}
	    	
	    		if(MainGui.whatToDo.equals("doctorBySpecialiation")) {
	    			if( specializations.getValue()==null )
	    				throw new EmptyFieldException();
	    			
	    			TreeSet<Doctor> docs = Hospital.getInstance().getDoctorBySpec(specializations.getValue());
	    			String toPrint = "";
	    			if( docs.isEmpty())
	    				toPrint = "No doctors to show";
	    			else if( !docs.isEmpty()) {
		    			for(Doctor d : docs) 
		    				toPrint += (d.toStringLong()+"\n");
	    			}
	    			String title = "Doctor's By Specialization";
	    			String header = specializations.getValue() + "'s " + "Doctors :";
	    			printAll( title, header, toPrint);
	    		}
	    	
	    		if(MainGui.whatToDo.equals("diseasesByRange")) {
	    			if( fromChar.getValue()==null || toChar.getValue()==null )
	    				throw new EmptyFieldException();
	    			if( toChar.getValue() < fromChar.getValue() ) 
	    				showAlert(AlertType.ERROR, "Error", "Error!","The second character should be lower than the first." );
	    			else {
		    			TreeSet<Disease> dis = Hospital.getInstance().getDiseasesByRange(fromChar.getValue(),
		    					toChar.getValue());
		    			String toPrint = "";
		    			if( dis.isEmpty() )
		    				toPrint = "No diseases to show";
		    			else if( !dis.isEmpty() ) {
		    				for(Disease d : dis) 
		    					toPrint += d + "\n";
		    			}
		    			String title = "Disaeses by Range";
		    			String header = "Diseases from " + Character.toUpperCase(fromChar.getValue()) + " to " +
		    					Character.toUpperCase(toChar.getValue());
		    			printAll( title, header, toPrint);
	    			}
	    		}
	 
	    		if( MainGui.currentDoctor != null )
		    		docsMainScreen();
		    	if(MainGui.currentNurse != null)
		    		nursesMainScreen();
		    	else
		    		mainScreen();
		    	
	    	}catch(EmptyFieldException e) {
	    		showAlert(AlertType.ERROR, "Error", "Cannot Display Information", e.getMessage());
    			return;		
	    	}
	    	catch(NullPointerException e) {
    			showAlert(AlertType.ERROR, "Error", "System Error", nullPointer);
    			return;
    		}	
	    }
	    
	    //***Treat Button Methods***//
	    
	    @FXML
	    void treat(ActionEvent event) {
	    	try {
	    		
	    		if(MainGui.whatToDo.equals("treatPatient")) {
	    		
	    			if(depts.getValue()==null )
	    				throw new EmptyFieldException();
	    			
	    			TreeSet<Patient> pat = Hospital.getInstance().treatPatients(depts.getValue());
	    			String toDisplay = "";
	    			String title = "Department's Treat Patients";
	    			String header = "Department "+ depts.getValue().getDeptName() + " Patients who's Condition Changed "
	    					+ " After Treatment : ";
	    			if( pat.isEmpty() ) {
	    				toDisplay ="There are no patients who's condition has changed in department "
	    			+ depts.getValue().getDeptName();
	    				
	    			}
	    			
	    			
	    			else if( !pat.isEmpty() ) {
	    				for( Patient p : pat )
	    					toDisplay += p.toStringLong() + "\n";
	    			}
	    			printAll( title, header, toDisplay);
	    		}
	    	
	    		if(MainGui.whatToDo.equals("treatDiseases")) {
	   
	    			if(depts.getValue()==null)
	    				throw new EmptyFieldException();
	    			
	    			TreeSet<Patient> pat = Hospital.getInstance().treatDiseases(depts.getValue());
	    			String toDisplay = "";
	    			String title = "Department's Treat Diseases";
	    			String header = "";
	    			if( !pat.isEmpty() ) {
	    				String diseaseType = "";
	    				if( pat.first().getDis().getClass().isInstance(ChronicDisease.class))
	    					diseaseType = "Chronic";
	    				else
	    					diseaseType = "Viral";
	    				header = "In Department "+ depts.getValue().getDeptName() + " There are More " + diseaseType
	    						+ " Disease Patients :";
	    				for( Patient p : pat)
	    					toDisplay += p.toStringLong() +"\n";
	    			}
	    			if( pat.isEmpty() )
	    				toDisplay = "There are no patients to show in " + depts.getValue().getDeptName();
	    			printAll(title, header , toDisplay);	
	    	
	    		}
	    		
	    		if( MainGui.currentDoctor != null )
		    		docsMainScreen();
		    	if(MainGui.currentNurse != null)
		    		nursesMainScreen();
		    	else
		    		mainScreen();
	    		
	    	}catch(EmptyFieldException e) {
    			showAlert(AlertType.ERROR, "Error", "Cannot Treat Diseases", e.getMessage());
    			return;	
    		}
    		catch(NullPointerException e) {
    			showAlert(AlertType.ERROR, "Error", "System Error", nullPointer);
    			return;
    		}
	    	
	    }
	    
	    
	    //***Check Button Methods***//
	    
	    @FXML
	    private void check() {
	    	
	    	try {
	    		
	    		if(MainGui.whatToDo.equals("checkPatient")) {
	    			
	    			if( MainGui.currentDoctor != null) {
	    				if( MainGui.currentDoctor.checkPatient(usersPatients.getValue()))
	    					showAlert(AlertType.INFORMATION, "Success", "Patient Checked!", null);
	    				else
	    					showAlert(AlertType.ERROR, "Error", "System Error", "Something went wrong, try again later.");		
	    			}
	    			else {
	    				if(MainGui.currentNurse.checkPatient(usersPatients.getValue()))
	    					showAlert(AlertType.INFORMATION, "Success", "Patient Checked!", null);
	    				else
	    					showAlert(AlertType.ERROR, "Error", "System Error", "Something went wrong, try again later.");		
	    			}
	    			
	    		}
	    		
	    		if(MainGui.whatToDo.equals("checkDisease")) {
	    			
	    			if(MainGui.currentDoctor != null) {
	    				if(MainGui.currentDoctor.checkDisease(usersPatients.getValue()))
	    					showAlert(AlertType.INFORMATION, "Success", "Disease Checked!", null);
	    				else
	    					showAlert(AlertType.ERROR, "Error", "System Error", "Something went wrong, try again later.");		
	    			}
	    			else {
	    				if(MainGui.currentNurse.checkDisease(usersPatients.getValue()))
	    					showAlert(AlertType.INFORMATION, "Success", "Disease Checked!", null);
	    				else
	    					showAlert(AlertType.ERROR, "Error", "System Error", "Something went wrong, try again later.");
	    			}
	    		}
	    		
	    		if( MainGui.currentDoctor != null )
		    		docsMainScreen();
		    	if(MainGui.currentNurse != null)
		    		nursesMainScreen();
	    		
	    	}catch( NullPointerException e) {
	    		showAlert(AlertType.ERROR, "Error", "System Error", nullPointer);
    			return;
	    	}
	    }
	    
	    @FXML
	    private void Login(){
	    	try {
	    		if( !admin.isSelected() && !nurButton.isSelected() && !docButton.isSelected() ) 
	    			throw new UserLoginException("Please Select User Type.");
	    		
	    		if( admin.isSelected() ) { //Admin Login.
	    			if( ID.getText().equals("admin") && password.getText().equals("admin")) {
	    				MainGui.currentDoctor=null;
	    				MainGui.currentNurse=null;
	    				showAlert(AlertType.INFORMATION, "Success", null, "Welcome Back Admin"  );
	    				mainScreen();
	    			}
	    			else
	    				throw new UserLoginException("One or more of the login details are wrong, try again.");
	    		}
	    			
	
	    		if(nurButton.isSelected()) //Nurse Login.
	    			if( Hospital.getInstance().getNursesById().containsKey(Integer.parseInt(ID.getText()))) 
	    				if( Hospital.getInstance().getRealNurse
	    						(Integer.parseInt(ID.getText())).getPassword().equals(password.getText())) {
	    					showAlert(AlertType.INFORMATION, "Success", null, "Welcome Back Nurse " + Hospital.getInstance()
	    					.getRealNurse(Integer.parseInt(ID.getText())).getLname() );
	    					MainGui.currentNurse = Hospital.getInstance().getRealNurse(Integer.parseInt(ID.getText()));
	    					nursesMainScreen();
	    				}
	    				else
	    					throw new UserLoginException(passwordFail);
	    			else 
	    				throw new UserLoginException(noUser);
	    		
	    		if( docButton.isSelected()) //Doctor Login.
	    			if(Hospital.getInstance().getDoctorsById().containsKey(Integer.parseInt(ID.getText())))
	    				if(Hospital.getInstance().getRealDoctor
	    						(Integer.parseInt(ID.getText())).getPassword().equals(password.getText())) {
	    					showAlert(AlertType.INFORMATION, "Success", null, "Welcome Back Dr." + Hospital.getInstance()
	    					.getRealDoctor(Integer.parseInt(ID.getText())).getLname());
	    					MainGui.currentDoctor = Hospital.getInstance().getRealDoctor(Integer.parseInt(ID.getText()));
	    					docsMainScreen();
	    				}
	    				else
	    					throw new UserLoginException(passwordFail);
	    			else
	    				throw new UserLoginException(noUser);
	    				
	    	}catch(UserLoginException u) {
	    		showAlert(AlertType.ERROR, "Error!", "Login Failed", u.getMessage());
	    		return;
	    	}catch(NumberFormatException n) {
	    		showAlert(AlertType.ERROR, "Error!", "Login Failed", "User name is incorrect! Insert your ID." );
	    		return;
	    	}
	    	catch(NullPointerException e) {
    			showAlert(AlertType.ERROR, "Error", "System Error", nullPointer);
    			return;
	    	}
	    }
	    
	    @FXML
	    private void LogOut() {
	 
			try {
				AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource("Login.fxml"));
				Scene scene = new Scene(root);
				MainGui.stage.setScene(scene);
				MainGui.stage.centerOnScreen();
				MainGui.stage.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	    
	    //***Load FXML Files***//
	    
	 	private void loadScreen(FXMLLoader loader) {
	 		
			try {
				AnchorPane pane = loader.load();
				stack.getChildren().clear();
				stack.getChildren().add(pane);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 	}
	 	
	 	private void showAlert(AlertType type, String title, String header ,String text) {
	 		Alert alert = new Alert(type);
	 		alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
	 		alert.setResizable(true);
	 		alert.setTitle(title);
	 		alert.setHeaderText(header);
	 		alert.setContentText(text);
	 		alert.showAndWait();
	 	}
	 	
	 	private void printAll(String title, String header, String toPrint) {
	 		
	 		Alert alert = new Alert(AlertType.INFORMATION);
			alert.setTitle(title);
			alert.setHeaderText(header);

			
			TextArea textArea = new TextArea(toPrint);
			textArea.setEditable(false);
			textArea.setWrapText(true);

			textArea.setMaxWidth(Double.MAX_VALUE);
			textArea.setMaxHeight(Double.MAX_VALUE);
			GridPane.setVgrow(textArea, Priority.ALWAYS);
			GridPane.setHgrow(textArea, Priority.ALWAYS);

			GridPane expContent = new GridPane();
			expContent.setMaxWidth(Double.MAX_VALUE);
			expContent.add(textArea, 0, 1);
			
			alert.getDialogPane().setExpandableContent(expContent);
			alert.getDialogPane().setExpanded(true);
			

			alert.showAndWait();
	 	}
	 	
	 	private void docsListsInitialize() {
	 		
	 		usersPatients.getItems().clear();
	 		usersHotelPatients.getItems().clear();
	 		usersNurses.getItems().clear();
	 		subDep.setValue(MainGui.currentDoctor.getsDepartment());
	 		subDep.setDisable(true);
	 		
	 		usrPatients = FXCollections.observableArrayList(Hospital.getInstance().getRealDoctor
				 (MainGui.currentDoctor.getId()).getsDepartment().getPatients());
	 		usersPatients.getItems().addAll(usrPatients);
			 
			for( Patient p: usersPatients.getItems()) {
				 if( Hospital.getInstance().getHotelPatientsById().containsKey(p.getId()))
					 usersHotelPatients.getItems().add(p);
			 }
			
			 usrNurses = FXCollections.observableArrayList(Hospital.getInstance().getRealDoctor
					 (MainGui.currentDoctor.getId()).getsDepartment().getNurses());
	 	}
	 	
	 	public void nurseListInitialize() {
	 		
	 		usersPatients.getItems().clear();
	 		usersHotelPatients.getItems().clear();
	 		usersNurses.getItems().clear();
	 		
	 		subDep.setValue(MainGui.currentNurse.getsDepartment());
	 		subDep.setDisable(true);
	 		
	 		usrPatients = FXCollections.observableArrayList(Hospital.getInstance().getRealNurse
				 (MainGui.currentNurse.getId()).getsDepartment().getPatients());
	 		usersPatients.getItems().addAll(usrPatients);
			 
			for( Patient p: usersPatients.getItems()) {
				 if( Hospital.getInstance().getHotelPatientsById().containsKey(p.getId()))
					 usersHotelPatients.getItems().add(p);
			 }
			 usrNurses = FXCollections.observableArrayList(Hospital.getInstance().getRealNurse
					 (MainGui.currentNurse.getId()).getsDepartment().getNurses());	
	 	}
	     
	    @FXML
	    void mainScreen() {
			try {
				VBox root = (VBox)FXMLLoader.load(getClass().getResource("Admin.fxml"));
				Scene scene = new Scene(root, MainGui.stage.getScene().getWidth(), MainGui.stage.getScene().getHeight());
				MainGui.stage.setScene(scene);
				MainGui.stage.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
	    }
	    
	    @FXML
	    void docsMainScreen() {
	    	try {
				VBox root = (VBox)FXMLLoader.load(getClass().getResource("doctorInSystem.fxml"));
				Scene scene = new Scene(root, MainGui.stage.getScene().getWidth(), MainGui.stage.getScene().getHeight());
				MainGui.stage.setScene(scene);
				MainGui.stage.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
	    
	    @FXML
	    void nursesMainScreen() {
	    	try {
				VBox root = (VBox)FXMLLoader.load(getClass().getResource("nurseInSystem.fxml"));
				Scene scene = new Scene(root, MainGui.stage.getScene().getWidth(), MainGui.stage.getScene().getHeight());
				MainGui.stage.setScene(scene);
				MainGui.stage.show();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }	    
}

	    