package View;

import java.awt.Label;
import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

public class enterTry {
	
	@FXML
    private AnchorPane screen2;
	
	//@FXML
	//private Label lab;
	public  void a() {
		System.out.println("here");
	}
	

}
