package View;

import Model.Doctor;
import Model.Hospital;

import Model.Nurse;
import javafx.application.Application;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;

import javafx.stage.Stage;

public class MainGui extends Application{
	
	static Stage stage;
	static String whatToDo = "";
	static Nurse currentNurse = null;
	static Doctor currentDoctor = null;
	
	@Override
	public void start(Stage primaryStage) {
		try {
			Hospital.readFile();
			AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource("Login.fxml"));
			Scene scene = new Scene(root);
			MainGui.stage=primaryStage;
			primaryStage.setScene(scene);
			primaryStage.setTitle("Hospital");
			primaryStage.getIcons().add(new Image("/View/Pictures/Icon.jpg"));
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void stop(){
		Hospital.writeToFile(Hospital.getInstance());
	}

}