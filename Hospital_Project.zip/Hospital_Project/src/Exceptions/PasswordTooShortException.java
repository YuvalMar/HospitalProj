package Exceptions;

public class PasswordTooShortException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public PasswordTooShortException() {
		super("Password Must be 6 Characters or More!");	
	}
		
}

